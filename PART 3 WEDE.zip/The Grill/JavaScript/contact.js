// JavaScript for form validation and smooth scroll functionality
document.addEventListener('DOMContentLoaded', function () {

    // Smooth Scroll to Sections
    const scrollLinks = document.querySelectorAll('a[href^="#"]');
    scrollLinks.forEach(link => {
        link.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            window.scrollTo({
                top: target.offsetTop - 50,
                behavior: 'smooth'
            });
        });
    });

    // Form validation
    const contactForm = document.getElementById('contactForm');
    const formMessage = document.getElementById('formMessage');

    // Validate Form Fields
    window.validateForm = function (event) {
        event.preventDefault();
        const name = document.getElementById('name').value.trim();
        const email = document.getElementById('email').value.trim();
        const message = document.getElementById('message').value.trim();

        if (name === '' || email === '' || message === '') {
            alert('Please fill out all fields.');
            return false;
        }

        // Simple email validation
        const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
        if (!emailRegex.test(email)) {
            alert('Please enter a valid email address.');
            return false;
        }

        // Display success message
        contactForm.reset();
        formMessage.style.display = 'block';

        // Optional: Send form data to a server (e.g., using AJAX)
        // Example of a mock server request:
        // sendFormData(name, email, message);

        return false; // Prevent default form submission for demonstration
    }

    // Optionally, you can use AJAX to send form data to a server
    // function sendFormData(name, email, message) {
    //     fetch('/submit-form', {
    //         method: 'POST',
    //         body: JSON.stringify({ name, email, message }),
    //         headers: { 'Content-Type': 'application/json' }
    //     }).then(response => {
    //         if (response.ok) {
    //             alert('Your message has been sent!');
    //         }
    //     });
    // }
});
