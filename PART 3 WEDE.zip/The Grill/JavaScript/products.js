let cart = [];
let cartCount = 0;
let total = 0;

function openModal(modalId) {
  document.getElementById(modalId).style.display = 'block';
}

function closeModal(modalId) {
  document.getElementById(modalId).style.display = 'none';
}

function addToCart(productType) {
  let selectedOption = getSelectedOption(productType);

  if (selectedOption) {
    let productDetails = {
      name: productType,
      option: selectedOption,
      price: parseFloat(selectedOption.split(" - R")[1]),
      quantity: 1
    };

    // Check if the product already exists in the cart
    let existingProductIndex = cart.findIndex(item => item.name === productDetails.name && item.option === productDetails.option);

    if (existingProductIndex !== -1) {
      // If it exists, increase the quantity
      cart[existingProductIndex].quantity++;
      cart[existingProductIndex].price += parseFloat(selectedOption.split(" - R")[1]);
    } else {
      // If it doesn't exist, add to cart
      cart.push(productDetails);
    }

    cartCount++;
    total += parseFloat(selectedOption.split(" - R")[1]);

    updateCart();
    closeModal(`${productType.toLowerCase()}Modal`);
  } else {
    alert('Please select an option.');
  }
}

function getSelectedOption(productType) {
  let options;

  switch (productType) {
    case 'Burger':
      options = document.getElementsByName('burger-size');
      break;
    case 'Coffee':
      options = document.getElementsByName('coffee-type');
      break;
    case 'Pizza':
      options = document.getElementsByName('pizza-size');
      break;
    case 'Drinks':
      options = document.getElementsByName('drink-type');
      break;
    case 'Dessert':
      options = document.getElementsByName('dessert-type');
      break;
    default:
      return null;
  }

  for (let option of options) {
    if (option.checked) {
      return option.value;
    }
  }

  return null;
}

function updateCart() {
  let cartCountElement = document.getElementById('cart-count');
  let cartTotalElement = document.getElementById('cart-total');
  let cartItemsElement = document.getElementById('cart-items');

  cartCountElement.textContent = cartCount;
  cartTotalElement.textContent = total.toFixed(2);

  cartItemsElement.innerHTML = ''; // Clear the previous cart items

  cart.forEach(item => {
    let li = document.createElement('li');
    li.textContent = `${item.name} - ${item.option} - R${item.price.toFixed(2)} x${item.quantity}`;
    cartItemsElement.appendChild(li);
  });
}
